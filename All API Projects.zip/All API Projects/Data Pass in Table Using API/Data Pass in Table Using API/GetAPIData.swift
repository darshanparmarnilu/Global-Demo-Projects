//
//  GetAPIData.swift
//  Data Pass in Table Using API
//
//  Created by MacBookAir_4 on 26/05/23.
//

import UIKit

class GetAPIData: UITableViewCell {

    @IBOutlet var myImageView: UIImageView!
    
    @IBOutlet var lblNews: UILabel!
    
    @IBOutlet var lblAutherName: UILabel!
    
   
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }

    override func prepareForReuse(){
        super.prepareForReuse()
        myImageView.image = nil
    }
}
