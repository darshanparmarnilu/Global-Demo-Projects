//
//  NewsPanel.swift
//  Data Pass in Table Using API
//
//  Created by MacBookAir_4 on 26/05/23.
//

import UIKit

class NewsPanel: UIViewController {

    @IBOutlet var imageNews: UIImageView!
    @IBOutlet var lblNewsContents: UILabel!
    @IBOutlet var lblHeadLines: UILabel!
    var newsContent:ArticalData = ArticalData(author: "", title: "", urlToImage: "", content: "")
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lblHeadLines.text = newsContent.title
        if newsContent.urlToImage != nil   {
            let url = URL(string: newsContent.urlToImage!)
            imageNews.downloadImage(from: url!)
            imageNews.contentMode = .scaleToFill
        }else{
            imageNews.image = UIImage(named: "avatar-3814081_1280")
        }
        lblNewsContents.text = newsContent.content
    }
}
