//
//  ViewController.swift
//  Data Pass in Table Using API
//
//  Created by MacBookAir_4 on 26/05/23.
//http://makeup-api.herokuapp.com/api/v1/products.json

import UIKit

class ViewController: UIViewController {
    
    var articallist = [ArticalData]()
    
    @IBOutlet var tableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchData()
    }
    
    func fetchData(){
        let url = URL(string: "https://newsapi.org/v2/top-headlines?country=us&apiKey=09e6198529ea454189a331720ef016a7")
        let datatask: Void = URLSession.shared.dataTask(with: url!) { (data, response, error )in
            guard let data = data, error == nil else{
                print("Error Execute For Accecing Data With Url")
                return
            }
            
            var newsStatement :NewsData!
            do{
                newsStatement = try JSONDecoder().decode(NewsData.self,from: data)
            }catch{
                print("Error Execute For Decoding The JSON  into Swift Structure \(error)")
            }
            self.articallist = newsStatement.articles
            DispatchQueue.main.async {
                self.tableview.reloadData()
            }
        }.resume()
    }
}

extension UIImageView{
    func downloadImage(from url:URL){
        contentMode = .scaleToFill
        let datatask: Void = URLSession.shared.dataTask(with: url) { (data, response, error ) in
            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200, let mineType = response?.mimeType?.hasPrefix("image"),
                  let data = data,error == nil,
                  let image = UIImage(data: data)
            else {
                return
            }
            DispatchQueue.main.async {
                self.image = image
            }
        }.resume()
    }
}

extension ViewController:UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return articallist.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! GetAPIData
        if articallist[indexPath.row] != nil{
            cell.lblAutherName.text = "Auther:- \(String(describing: articallist[indexPath.row].author))"
        }else{
            cell.lblAutherName.text = "No Auther Available"
        }
        cell.lblNews.text = articallist[indexPath.row].title
        if articallist[indexPath.row].urlToImage != nil{
            let url = URL(string: articallist[indexPath.row].urlToImage!)
            cell.myImageView.downloadImage(from: url!)
            cell.contentMode = .scaleToFill
        }else{
            cell.myImageView.image = UIImage(named: "avatar-3814081_1280")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let nextvc = self.storyboard?.instantiateViewController(withIdentifier: "NewsPanel") as! NewsPanel
        nextvc.newsContent = articallist[indexPath.row]
        self.navigationController?.pushViewController(nextvc, animated: true)
    }
    
}
