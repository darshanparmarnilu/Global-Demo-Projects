//
//  ArticalData.swift
//  Data Pass in Table Using API
//
//  Created by MacBookAir_4 on 26/05/23.
//

import Foundation

struct ArticalData:Codable{
    let author: String?
    let title: String
    let urlToImage: String?
    let content: String?
}
