//
//  ViewController.swift
//  Download Image Using API
//
//  Created by MacBookAir_4 on 25/05/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var indicator: UIActivityIndicatorView!
    @IBOutlet var btnDownload: UIButton!
    @IBOutlet var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        indicator.isHidden = true
        // Do any additional setup after loading the view.
    }

        
    @IBAction func Downoad(_ sender: UIButton) {
        indicator.isHidden = false
        let strUrl = "https://wallpapershome.com/images/wallpapers/love-image-2160x3840-8k-21487.jpg"
         let myUrl = URL(string: strUrl)
        
        var request = URLRequest(url: myUrl!)
        request.httpMethod = "GET"
        
        let urlSession = URLSession.shared
        
        let dataTask:URLSessionDataTask = urlSession.dataTask(with: request, completionHandler: downloadHandler(urlData:response:error:))
        
        dataTask.resume()
                                           
        }
        
        func downloadHandler(urlData:Data?,response:URLResponse?,error:Error?)->Void{
            if (urlData != nil && error == nil){
                let downloadedImage:UIImage = UIImage(data: urlData!)!
                
                
                let mainQ = DispatchQueue.main
                mainQ.async(execute:{
                    self.imageView.image = downloadedImage
                    self.indicator.isHidden = true
                } )
                
            }
        }
}

