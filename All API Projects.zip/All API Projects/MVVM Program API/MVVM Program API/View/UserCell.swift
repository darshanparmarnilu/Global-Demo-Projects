//
//  Usercell.swift
//  MVVM Program API
//
//  Created by MacBookAir_4 on 29/05/23.
//

import UIKit

class Usercell: UITableViewCell {

    @IBOutlet var lblID: UILabel!
    @IBOutlet var lblTitle: UILabel!
    @IBOutlet var lblCompleted: UILabel!
    var modelUser:UserModel?{
        didSet{
            userConfiguration()
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func userConfiguration(){
        let status = modelUser?.getStatusAndColor()
        lblCompleted.text = status!.0
        lblCompleted.textColor = status!.1
        if let id = modelUser?.id{
            lblID.text = "\(id)"
        }else{
            lblID.text = "No ID"
        }
        lblTitle.text = modelUser?.title
    }
}
