//
//  ViewController.swift
//  MVVM Program API
//
//  Created by MacBookAir_4 on 29/05/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var tableview: UITableView!
    var viewModelUser = UserViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModelUser.vc = self
        viewModelUser.getDataUsinfAlamofire()
        
        tableview.register(UINib(nibName: "Usercell", bundle: nil), forCellReuseIdentifier: "Usercell")
    }
}

extension ViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModelUser.arrUser.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "Usercell", for: indexPath) as! Usercell
        let modelUser = viewModelUser.arrUser[indexPath.row]
        cell.modelUser = modelUser
        //cell.userConfiguration()
        
//        let status = viewModelUser.arrUser[indexPath.row].getStatusAndColor()
//        cell.lblCompleted.text = status.0
//        cell.lblCompleted.textColor = status.1
//        cell.lblID.text = "\(viewModelUser.arrUser[indexPath.row].id!)"
//        cell.lblTitle.text = "\(viewModelUser.arrUser[indexPath.row].title!)"
       // cell.lblCompleted.text = "\(viewModelUser.arrUser[indexPath.row].completed)"
        return cell
    }
}
