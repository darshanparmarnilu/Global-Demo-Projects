//
//  UserViewModel.swift
//  MVVM Program API
//
//  Created by MacBookAir_4 on 29/05/23.
//

import Foundation
import Alamofire

class UserViewModel{
    
    weak var vc:ViewController?
    let url = URL(string: "https://jsonplaceholder.typicode.com/todos/")
    var arrUser = [UserModel]()
    
    
    func getDataUsinfAlamofire(){
        AF.request("https://jsonplaceholder.typicode.com/todos/")
            .response{ response in
                if let data = response.data{
                    do {
                        let userResponse = try JSONDecoder().decode([UserModel].self, from: data)
                        for modelUser in userResponse{
                            self.arrUser.append(modelUser)
                        }
                        //                        print(self.arrUser)
                        //                        print(userResponse)
                        self.arrUser.append(contentsOf: userResponse)
                    }catch{
                        print(error.localizedDescription)
                    }
                    
                    DispatchQueue.main.async {
                        self.vc?.tableview.reloadData()
                    }
                }
            }
    }
    
//    func getAllUserData(){
//        URLSession.shared.dataTask(with:url! , completionHandler: {(data ,response, error) in
//            if error == nil{
//
//                if let data = data{
//                    do {
//                        let userResponse = try JSONDecoder().decode([UserModel].self, from: data)
//                        for modelUser in userResponse{
//                            self.arrUser.append(modelUser)
//                        }
//                        self.arrUser.append(contentsOf: userResponse)
//                    }catch{
//                        print(error.localizedDescription)
//                    }
//
//                    DispatchQueue.main.async {
//                        self.vc?.tableview.reloadData()
//                    }
//                }
//
//            }else{
//                print(error?.localizedDescription)
//            }
//        }).resume()
//    }
}
