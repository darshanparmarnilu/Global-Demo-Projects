//
//  jsonModel.swift
//  API Calling Using SwiftyJSON
//
//  Created by MacBookAir_4 on 30/05/23.
//

import Foundation
import SwiftyJSON

struct jsonModel{
    var artistName:String = ""
    var trackCensoredName:String = ""
    var artworkUrl100:String = ""
    var artistId:String = ""
    var collectionCensoredName: String = ""
    var country:String = ""
    
    init(){
        
    }
    
    init(json:JSON){
        artistName = json["artistName"].stringValue
        trackCensoredName = json["trackCensoredName"].stringValue
        artworkUrl100 = json["artworkUrl100"].stringValue
        artistId = json["artistId"].stringValue
        collectionCensoredName = json["collectionCensoredName"].stringValue
        country = json["country"].stringValue
    }
}
