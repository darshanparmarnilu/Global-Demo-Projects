//
//  StaticTableViewController.swift
//  API Calling Using SwiftyJSON
//
//  Created by MacBookAir_4 on 30/05/23.
//

import UIKit

class StaticTableViewController: UITableViewController {
    
    @IBOutlet var lblArtistID: UILabel!
    
    @IBOutlet var profileImage: UIImageView!
    @IBOutlet var country: UILabel!
    @IBOutlet var lblcollactionConsolName: UILabel!
    @IBOutlet var lblArtistName: UILabel!
    @IBOutlet var lblTrackConsolName: UILabel!
    
    var modelData = jsonModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        lblArtistID.text = "ID:-\(modelData.artistId)"
        lblArtistName.text = "Name:-\(modelData.artistName)"
        lblcollactionConsolName.text = "Coll_Name:-\(modelData.collectionCensoredName)"
        lblTrackConsolName.text = "Track_Name:-\(modelData.trackCensoredName)"
        country.text = "Country:-\(modelData.country)"
        profileImage.kf.setImage(with: URL(string: modelData.artworkUrl100))
        
    }
    override func viewWillAppear(_ animated: Bool) {
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}
