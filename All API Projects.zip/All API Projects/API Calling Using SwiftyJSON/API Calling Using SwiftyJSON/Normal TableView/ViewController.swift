//
//  ViewController.swift
//  API Calling Using SwiftyJSON
//
//  Created by MacBookAir_4 on 30/05/23.
//` https://itunes.apple.com/search?media=music&term=bollywood

import UIKit
import SwiftyJSON
import Kingfisher


class ViewController: UIViewController {
    var arrData = [jsonModel]()
    @IBOutlet var tableview: UITableView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        jsonParsing()
    }
    
    func jsonParsing(){
        let urlString = URL(string: "https://itunes.apple.com/search?media=music&term=bollywood")
        
        URLSession.shared.dataTask(with: urlString!) { (data, response, error) in
            guard let data = data else{
                return
            }
            do{
                let json = try JSON(data:data)
                let results = json["results"]
                print(results)
                for arr in results.arrayValue{
                    self.arrData.append(jsonModel(json: arr))
                }
                DispatchQueue.main.async {
                    self.tableview.reloadData()
                }
            }catch{
                print(error.localizedDescription)
            }
        }.resume()
    }
}

extension ViewController:UITableViewDelegate,UITableViewDataSource{
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! JSONTableViewCell
        cell.lblartistName.text = arrData[indexPath.row].artistName
        cell.lbltrackCensoredName.text = arrData[indexPath.row].trackCensoredName
        let url = URL(string: arrData[indexPath.row].artworkUrl100)
        cell.imgJsonImage.kf.setImage(with: url)
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let obj = self.storyboard?.instantiateViewController(withIdentifier: "StaticTableViewController") as! StaticTableViewController
        obj.modelData = arrData[indexPath.row]
        self.navigationController?.pushViewController(obj, animated: true)
    }
}
