//
//  JSONTableViewCell.swift
//  API Calling Using SwiftyJSON
//
//  Created by MacBookAir_4 on 30/05/23.
//

import UIKit

class JSONTableViewCell: UITableViewCell {

    @IBOutlet var imgJsonImage: UIImageView!
    @IBOutlet var lbltrackCensoredName: UILabel!
    @IBOutlet var lblartistName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
