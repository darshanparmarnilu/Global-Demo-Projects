//
//  ViewController.swift
//  API
//
//  Created by MacBookAir_4 on 23/05/23.
//

import UIKit

class ViewController: UIViewController {

    //https://jsonplaceholder.typicode.com/todos/1

    @IBOutlet var txttitles: UITextField!
    
    @IBOutlet var txtBody: UITextField!
    
    @IBOutlet var txtuerID: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func Post(_ sender: UIButton) {
        self.setupPostMethod()
    }
    
}
extension Dictionary{
    func precentEscaped()->String{
        return map{(key, value) in
            
            let escapedKey = "\(key)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            
            let escapedValue = "\(value)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            
            return escapedKey + "=" + escapedValue
        }
        .joined(separator: "&")
    }
}
extension CharacterSet{
    static let urlQueryValueAllowed: CharacterSet = {
        let generalDelimitersToEncode = ":#[]@"
        let subDelimitersToEncode = "!$&'()*+,;="
        var allowd =  CharacterSet.urlQueryAllowed
        allowd.remove(charactersIn: "\(generalDelimitersToEncode)\(subDelimitersToEncode)")
        return allowd
    }()
}

extension ViewController{
    func setupPostMethod(){
        guard let uid = self.txtuerID.text else {return}
        guard let title = self.txttitles.text else {return}
        guard let body = self.txtBody.text else{return}
        
        if let url = URL(string: "https://jsonplaceholder.typicode.com/todos/"){
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            
            let parameter :[String:Any] = [
            "userID": uid,
            "title": title,
            "body": body
            ]
            request.httpBody = parameter.precentEscaped().data(using: .utf8)
            URLSession.shared.dataTask(with: request){( data, response, error) in
                guard let data = data else{
                    if error == nil{
                        print(error?.localizedDescription ?? "Unknown Error")
                    }
                    return
                }
                
                if let response = response as? HTTPURLResponse{
                    guard(200...299) ~= response.statusCode else{
                        print("Status Code:-\(response.statusCode)")
                        print(response)
                        return
                    }
                }
                do{
                    let json = try JSONSerialization.jsonObject(with: data,options:  [])
                    print(json)
                }catch let error{
                    print(error.localizedDescription)
                }
            }.resume()
        }
        
    }
}
