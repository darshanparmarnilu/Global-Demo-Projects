//
//  API_CallingApp.swift
//  API Calling
//
//  Created by MacBookAir_4 on 23/05/23.
//

import SwiftUI

@main
struct API_CallingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
