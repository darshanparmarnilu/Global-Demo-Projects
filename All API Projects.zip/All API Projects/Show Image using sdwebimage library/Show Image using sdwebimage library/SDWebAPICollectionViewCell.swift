//
//  SDWebAPICollectionViewCell.swift
//  Show Image using sdwebimage library
//
//  Created by MacBookAir_4 on 29/05/23.
//

import UIKit

class SDWebAPICollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var imgView: UIImageView!
    
    override func prepareForReuse() {
        super.prepareForReuse()
        imgView.image = nil
    }
}
