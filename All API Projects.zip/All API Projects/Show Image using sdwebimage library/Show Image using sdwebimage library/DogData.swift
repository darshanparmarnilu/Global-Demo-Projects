//
//  DogData.swift
//  Show Image using sdwebimage library
//
//  Created by MacBookAir_4 on 29/05/23.
//

import Foundation

struct DogData:Codable{
    let message : [String]
    let status:String
}
