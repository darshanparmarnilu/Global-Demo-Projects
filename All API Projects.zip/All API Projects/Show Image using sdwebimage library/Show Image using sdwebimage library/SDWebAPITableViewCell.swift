//
//  SDWebAPITableViewCell.swift
//  Show Image using sdwebimage library
//
//  Created by MacBookAir_4 on 29/05/23.
//

import UIKit

class SDWebAPITableViewCell: UITableViewCell {

    @IBOutlet var imgWebAPI: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        imgWebAPI.image = nil
    }
}
