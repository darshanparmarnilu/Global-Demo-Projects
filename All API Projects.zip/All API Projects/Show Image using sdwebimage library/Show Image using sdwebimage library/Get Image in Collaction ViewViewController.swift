//
//  Get Image in Collaction ViewViewController.swift
//  Show Image using sdwebimage library
//
//  Created by MacBookAir_4 on 29/05/23.
//

import UIKit
import SDWebImage

class Get_Image_in_Collaction_ViewViewController: UIViewController {
    
    var dogAllData:DogData?
    var dogAllimageLinks = [String]()
    
    @IBOutlet var collactionview: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchData()
        
    }
    func fetchData(){
        let url = URL(string: "https://dog.ceo/api/breed/hound/images")
        
        let _: Void = URLSession.shared.dataTask(with: url!,completionHandler:{(data, response, error) in
            guard let data = data,error == nil else{
                print("Error Occuerd While Accesing Data:-\(error?.localizedDescription ?? "Unknown Error")")
                return
            }
            
            var dataObject:DogData?
            do{
                dataObject = try JSONDecoder().decode(DogData.self, from: data)
            }catch{
                print("Error While Decoding JSON into Swift Structure \(error)")
            }
            self.dogAllData = dataObject
            self.dogAllimageLinks = self.dogAllData!.message
            
            DispatchQueue.main.async {
                self.collactionview.reloadData()
            }
            
        }).resume()
    }
}

extension Get_Image_in_Collaction_ViewViewController:UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dogAllimageLinks.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collactionview.dequeueReusableCell(withReuseIdentifier: "collection", for: indexPath) as! SDWebAPICollectionViewCell
        
        if let imgUrl =  URL(string: dogAllimageLinks[indexPath.row]){
            cell.imgView.sd_imageIndicator = SDWebImageActivityIndicator.gray
            cell.imgView.sd_imageIndicator?.startAnimatingIndicator()
            cell.imgView.sd_setImage(with:imgUrl , placeholderImage: UIImage(named: "avatar-3814081_1280"), options:.continueInBackground, completed:nil)
            cell.imgView.contentMode = .scaleToFill
            cell.imgView.layer.cornerRadius = 50
        }else{
            print("Invalid URl")
            cell.imgView.image = UIImage(named: "avatar-3814081_1280")
        }
        
        return cell
    }
    
    
}

extension Get_Image_in_Collaction_ViewViewController:UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.size.width - 10) / 2
        let height = width * 1.2
        return CGSize(width: width, height: height)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}
