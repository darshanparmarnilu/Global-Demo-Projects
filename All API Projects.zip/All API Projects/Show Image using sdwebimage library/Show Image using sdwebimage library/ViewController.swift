//
//  ViewController.swift
//  Show Image using sdwebimage library
//
//  Created by MacBookAir_4 on 29/05/23.
//

import UIKit
import SDWebImage

class ViewController: UIViewController {

    var dogAllData:DogData?
    var dogImageAllLinks = [String]()
    
    @IBOutlet var tabelview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tabelview.delegate = self
        tabelview.dataSource = self
        
        fetchdata()
        
        
    }

    func fetchdata(){
        let url = URL(string: "https://dog.ceo/api/breed/hound/images")
        let task: Void = URLSession.shared.dataTask(with: url!, completionHandler: {
            (data, response, error) in
            guard let data = data, error == nil else{
                print("Error Occuerd While Accesing Data:-\(error?.localizedDescription ?? "Unknown Error")")
                return
            }
            
            var dogObject:DogData?
            do{
                dogObject = try JSONDecoder().decode(DogData.self,from: data)
            }catch{
                print("Error While Decoding JSON into Swift Structure \(error)")
            }
            self.dogAllData = dogObject
            self.dogImageAllLinks = self.dogAllData!.message
            DispatchQueue.main.async {
                self.tabelview.reloadData()
            }
        }) .resume()
    }
}

extension ViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dogImageAllLinks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tabelview.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! SDWebAPITableViewCell
        
        if let imgURL = URL(string: dogImageAllLinks[indexPath.row]){
            cell.imgWebAPI.sd_imageIndicator = SDWebImageActivityIndicator.gray
            cell.imgWebAPI.sd_imageIndicator?.startAnimatingIndicator()
            cell.imgWebAPI.sd_setImage(with: imgURL, placeholderImage: UIImage(named: "avatar-3814081_1280"), options: .continueInBackground , completed: nil)
            
            cell.imgWebAPI.contentMode = .scaleToFill
            cell.imgWebAPI.layer.cornerRadius = 50
        }else{
            print("Invalid Url")
            cell.imgWebAPI.image = UIImage(named: "avatar-3814081_1280")
        }
        
        return cell
    }
    
    
}
