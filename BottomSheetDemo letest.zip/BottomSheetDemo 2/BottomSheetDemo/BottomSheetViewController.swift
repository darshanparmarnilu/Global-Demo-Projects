//
//  BottomSheetViewController.swift
//  BottomSheetDemo
//
//  Created by MacBookAir_36 on 23/06/24.
//

import UIKit

class BottomSheetViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }


    
    @IBAction func btnNext(_ sender: UIButton) {
        
        if let navigationController = self.navigationController {
            let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = mainStoryboard.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
            
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
        
    }
    
}
