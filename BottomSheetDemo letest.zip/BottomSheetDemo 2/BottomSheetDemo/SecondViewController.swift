//
//  SecondViewController.swift
//  BottomSheetDemo
//
//  Created by MacBookAir_36 on 23/06/24.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    @IBAction func btnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    

}
