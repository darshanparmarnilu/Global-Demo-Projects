//
//  ViewController.swift
//  BottomSheetDemo
//
//  Created by MacBookAir_36 on 23/06/24.
//

import UIKit

class ViewController: UIViewController {

    let sheet = BottomSheetViewController()
    var initialSheetY: CGFloat = 0
    var initialSheetHeight: CGFloat = 0
    var middlePositionY: CGFloat = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        setupViewHierarchy()
        setupViewAttributes()
        setupLayout()
    }
    
    func setupViewHierarchy() {
        self.addChild(sheet)
        self.view.addSubview(sheet.view)
        sheet.didMove(toParent: self)
    }

    func setupViewAttributes() {
        sheet.view.translatesAutoresizingMaskIntoConstraints = false

        let gestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture))
        gestureRecognizer.cancelsTouchesInView = false
        sheet.view.addGestureRecognizer(gestureRecognizer)
    }

    func setupLayout() {
        let initialHeight = self.view.frame.height / 4
        initialSheetHeight = initialHeight
        middlePositionY = self.view.frame.height - (initialHeight / 2)

        NSLayoutConstraint.activate([
            sheet.view.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
            sheet.view.trailingAnchor.constraint(equalTo: self.view.trailingAnchor),
            sheet.view.heightAnchor.constraint(equalToConstant: self.view.frame.height),
            sheet.view.topAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -initialHeight)
        ])
    }
    
    @objc func handlePanGesture(gesture: UIPanGestureRecognizer) {
        let translation = gesture.translation(in: self.view)
        let velocity = gesture.velocity(in: self.view)

        switch gesture.state {
        case .began:
            initialSheetY = sheet.view.frame.origin.y

        case .changed:
            let newY = initialSheetY + translation.y
            let minY = self.view.frame.height - self.view.frame.height // Top of the screen
            let maxY = self.view.frame.height - initialSheetHeight // Bottom sheet at initial one-third height
            sheet.view.frame.origin.y = min(maxY, max(minY, newY))

            // Update the initialSheetY to prevent jumping
            initialSheetY = sheet.view.frame.origin.y

        case .ended:
            var targetY: CGFloat
            let currentY = sheet.view.frame.origin.y

            if velocity.y < 0 { // Dragging up
                targetY = currentY // Expand to full screen
            } else if velocity.y > 0 || currentY > middlePositionY { // Dragging down or past middle
                targetY = self.view.frame.height - self.initialSheetHeight // Return to initial position
                targetY = currentY
            } else {
//                targetY = middlePositionY // Snap to the middle position
                targetY = middlePositionY
            }

            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseOut, animations: {
                self.sheet.view.frame.origin.y = targetY
            }, completion: nil)

        default:
            break
        }

        gesture.setTranslation(.zero, in: self.view)
    }
}




//@objc func handlePanGesture(gesture: UIPanGestureRecognizer) {
//    let translation = gesture.translation(in: self.view)
//    let velocity = gesture.velocity(in: self.view)
//
//    switch gesture.state {
//    case .began:
//        initialSheetY = sheet.view.frame.origin.y
//
//    case .changed:
//        let newY = initialSheetY + translation.y
//        let minY = self.view.frame.height - self.view.frame.height // Top of the screen
//        let maxY = self.view.frame.height - initialSheetHeight // Bottom sheet at initial one-third height
//        sheet.view.frame.origin.y = min(maxY, max(minY, newY))
//
//        // Update the initialSheetY to prevent jumping
//        initialSheetY = sheet.view.frame.origin.y
//
//    case .ended:
//        if velocity.y < 0 { // Dragging up
//            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseOut, animations: {
//                self.sheet.view.frame.origin.y = 0 // Expand to full screen
//            }, completion: nil)
//        } else { // Dragging down
//            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseOut, animations: {
//                self.sheet.view.frame.origin.y = self.view.frame.height - self.initialSheetHeight // Return to initial position
//            }, completion: nil)
//        }
//
//    default:
//        break
//    }
//
//    gesture.setTranslation(.zero, in: self.view)
//}
